package dev.koji.koko

import com.mojang.logging.LogUtils
import dev.koji.koko.common.CommonRegistry
import dev.koji.koko.compact.Compatibilities
import net.neoforged.bus.api.IEventBus
import net.neoforged.fml.ModContainer
import net.neoforged.fml.common.Mod
import net.neoforged.fml.config.ModConfig

@Mod(Koko.MOD_ID)
class NeoKoko(modEventBus: IEventBus, modContainer: ModContainer) {
    init {
        val logger = LogUtils.getLogger()

        logger.info("Koko is loading...")

        Koko.init(NeoKokoConfig, NeoSkillsHandler)

        modContainer.registerConfig(ModConfig.Type.COMMON, NeoKokoConfig.SPEC)

        CommonRegistry.register(modEventBus)
        Compatibilities.register()

        logger.info("Koko has been successfully loaded.")
    }
}