/*
 * Copyright 2021-2023 QuiltMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.quiltmc.parsers.json;

public class FormatViolationException extends ParseException {
	public FormatViolationException() {
		super();
	}

	public FormatViolationException(String message) {
		super(message);
	}

	public FormatViolationException(Throwable cause) {
		super(cause);
	}

	public FormatViolationException(String message, Throwable cause) {
		super(message, cause);
	}

	public FormatViolationException(JsonReader reader) {
		super(reader, "Format violation");
	}

	public FormatViolationException(JsonReader reader, String message) {
		super(reader, message);
	}

	public FormatViolationException(JsonReader reader, Throwable cause) {
		super(reader, "Format violation", cause);
	}

	public FormatViolationException(JsonReader reader, String message, Throwable cause) {
		super(reader, message, cause);
	}
}
